import React, { useState } from 'react';
import axios from 'axios';

const FormularioProducto = ({ productoParaEditar, refrescarProductos }) => {
    const [nombre, setNombre] = useState(productoParaEditar ? productoParaEditar.nombre : '');
    const [descripcion, setDescripcion] = useState(productoParaEditar ? productoParaEditar.descripcion : '');
    const [precio, setPrecio] = useState(productoParaEditar ? productoParaEditar.precio : '');
    const [disponible, setDisponible] = useState(productoParaEditar ? productoParaEditar.disponible : true);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const producto = { nombre, descripcion, precio, disponible };
        if (productoParaEditar) {
            await axios.put(`/api/productos/${productoParaEditar.id}`, producto);
        } else {
            await axios.post('/api/productos', producto);
        }
        refrescarProductos();
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Nombre" required />
            <input type="text" value={descripcion} onChange={(e) => setDescripcion(e.target.value)} placeholder="Descripción" required />
            <input type="number" value={precio} onChange={(e) => setPrecio(e.target.value)} placeholder="Precio" required />
            <label>
                Disponible:
                <input type="checkbox" checked={disponible} onChange={(e) => setDisponible(e.target.checked)} />
            </label>
            <button type="submit">{productoParaEditar ? 'Actualizar' : 'Agregar'}</button>
        </form>
    );
};

export default FormularioProducto;
