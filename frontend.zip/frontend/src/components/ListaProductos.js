import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ListaProductos = ({ onEdit, onDelete }) => {
    const [productos, setProductos] = useState([]);

    useEffect(() => {
        fetchProductos();
    }, []);

    const fetchProductos = async () => {
        const response = await axios.get('/api/productos');
        setProductos(response.data);
    };

    return (
        <div>
            <h2>Lista de Productos</h2>
            <ul>
                {productos.map(producto => (
                    <li key={producto.id}>
                        {producto.nombre} - ${producto.precio} - {producto.disponible ? 'Disponible' : 'No Disponible'}
                        <button onClick={() => onEdit(producto)}>Editar</button>
                        <button onClick={() => onDelete(producto.id)}>Eliminar</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ListaProductos;
