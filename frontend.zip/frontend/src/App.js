import React, { useState } from 'react';
import axios from 'axios';
import ListaProductos from './components/ListaProductos';
import FormularioProducto from './components/FormularioProducto';

const App = () => {
    const [productoParaEditar, setProductoParaEditar] = useState(null);

    const handleEdit = (producto) => {
        setProductoParaEditar(producto);
    };

    const handleDelete = async (id) => {
        await axios.delete(`/api/productos/${id}`);
        refrescarProductos();
    };

    const refrescarProductos = () => {
        setProductoParaEditar(null);
    };

    return (
        <div>
            <h1>Gestión de Inventario</h1
