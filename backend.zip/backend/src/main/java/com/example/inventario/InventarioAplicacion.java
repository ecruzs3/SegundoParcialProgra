package com.example.inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioAplicacion {
    public static void main(String[] args) {
        SpringApplication.run(InventarioAplicacion.class, args);
    }
}