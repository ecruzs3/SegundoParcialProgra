package com.example.inventario.controlador;

import com.example.inventario.modelo.Producto;
import com.example.inventario.repositorio.ProductoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/productos")
public class ProductoControlador {
    @Autowired
    private ProductoRepositorio productoRepositorio;

    @GetMapping
    public List<Producto> obtenerTodosLosProductos() {
        return productoRepositorio.findAll();
    }

    @PostMapping
    public Producto crearProducto(@RequestBody Producto producto) {
        return productoRepositorio.save(producto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Producto> actualizarProducto(@PathVariable Long id, @RequestBody Producto productoDetalles) {
        Producto producto = productoRepositorio.findById(id).orElseThrow();
        producto.setNombre(productoDetalles.getNombre());
        producto.setDescripcion(productoDetalles.getDescripcion());
        producto.setPrecio(productoDetalles.getPrecio());
        producto.setDisponible(productoDetalles.getDisponible());
        return ResponseEntity.ok(productoRepositorio.save(producto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarProducto(@PathVariable Long id) {
        productoRepositorio.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}